

This project is written by me using java IDE Netbeans 7.3.1 and MS Access 2010 as Back end for
thesis Submission of the Engineering students in java.
This project is very helpful for the beginners who wanna learn database programming in java.....

Main Features:

1. Nurse/Wardboy Entry
2. Doctors Entry
3. Patient
3.1. Registration
3.2. Services
3.3. Admit To Room or Ward
3.4. Discharge from Room or Ward
3.5. Billing
4. Automatic allocation and deallocation of Room or beds from ward

Login Information :
Username- admin
Password -12345

In order to run the project, you must have to first connect your database to the DataSources(ODBC).

Instructions:
1.Open Control Panel
2 Click Administrative Tools
3.Open DataSources(ODBC)
4.Click the Add button the select Microsoft Access Driver(*mdb,*accdb) the click Finish
5.On the Dialog window, fill the Data Source Name field with the name of the database, and that is HMS_DB.
6.Click the select button to browse the database and click OK

After that you're done.